
var socket = io();

/**
 * @return {string}
 */

//Drag objects
$(function(){
    $(".draggable").draggable();
});

/**
 * @return {string}
 */
//go back
function goBack() {
    window.history.back();
}

//Checking time every second
function LiveTime(){
    var timeNow = new Date();
    return timeNow.getHours() + ":" + timeNow.getMinutes();

}

var UpdateChatTime = setInterval(function(){
    LiveTime();
}, 1000);

//Creating new room
function newRoom(id){
    event.preventDefault();

    if(id === ''){
        $('div').remove('#error');
        $('.modal-body').append('<br/><div id="error" class="alert alert-danger fade in"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <strong>Error:</strong> Please, enter a room name first. </div>');
    }
    else {
        socket.emit('sendRoom', id);
        $("#roomId").append("<option value='"+id+"'>"+id+"</option>");
        $("#roomName").val('');
    }
}


$(function() {
    $('#Auth').submit(function (e) {
        e.preventDefault();

        var username = $("#userName").val();
        var room = $("#roomId").val();

        if (username === "") {
            $('div').remove('#error');
            $('.container-fluid').append('<div id="error" class="alert alert-danger fade in"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <strong>Error:</strong> Please, enter a username first. </div>');
        }
        else if(room === null){
            $('div').remove('#error');
            $('.container-fluid').append('<div id="error" class="alert alert-warning fade in"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <strong>Error:</strong> Please, select room. </div>');
        }
        else {
            socket.emit("session", username, room, function(id, roomId){
                if(id){
                    $(".userAuth").remove();
                    $(".chatWrap").show();
                }
                else{
                    $('div').remove('#error');
                    $('.container-fluid').append('<div id="error" class="alert alert-danger fade in"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <strong>Error:</strong> '+ username +' already taken! </div>');

                }
            });
        }

    });

    $('#newMSG').submit(function (e) {
        e.preventDefault();

        var msg = $("#msg").val();

        if (msg == "") {
            $('div').remove('#error');
            $('.container-fluid').append('<div id="error" class="alert alert-danger fade in"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <strong>Error:</strong> Please, enter a message first. </div>');
        }
        else {
            socket.emit('message', msg);
            $("#msg").val('').focus();
        }

    });
});

//SOCKETS ON
//Success
socket.on('success', function(message){
    $('div').remove('#success');
    $( '.modal' ).modal( 'hide' ).data( 'bs.modal', null );

    $('.container-fluid').append('<div id="success" class="alert alert-success fade in"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+ message +'</div>');
    $('#success').hide(5000);

});

//Errors
socket.on('errors', function(message){
    $('div').remove('#error');
    $('.modal-body').append('<div id="error" class="alert alert-danger fade in"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <strong>Error:</strong> '+ message +' </div>');

});

//Nicknames handler
socket.on('nicknames', function(data){
        for(var i=0;i,i<data.length;i++){
           console.log(data[i]['username']);
        }
});

socket.on('test', function(data){
    if(data.length === 0){}
    else {
        for(var p=0;p<data.length;p++){
            console.log(data[0]);
        }
    }
});

//Room display
socket.on('DisplayRooms', function(roomsId){

    for(var i=0; i<roomsId.length; i++){
        if(i == -1){}
        else{
            $('#roomId').append("<option value='"+roomsId[i]['name']+"'>"+roomsId[i]['name']+"</option>");
        }
    }
});

//Sending messages
socket.on('message', function(msg, id, room){

    $('#message').append($('<li class="left clearfix">' +
        '</span>' +
        '<div class="chat-body clearfix">' +
        '<div class="header">' +
        '<strong class="primary-font">'+id+':</strong><small class="pull-right text-muted">'+LiveTime()+'</small><p>'+msg+'</p></div></div></li>'));

});
